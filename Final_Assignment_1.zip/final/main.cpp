#include <windows.h>
#include <GL/glut.h>
#include<iostream>
using namespace std;

GLfloat i = 0.0f;
GLfloat j = 0.0f;
GLfloat k = 0.0f;

void initGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

void Idle()
{
    glutPostRedisplay();
}
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, 0.7f);
    glVertex2f(0.0f, 0.6f);

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.7f, 0.0f);
    glVertex2f(0.6f, 0.0f);

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, -0.7f);
    glVertex2f(0.0f, -0.6f);

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.7f, 0.0f);
    glVertex2f(-0.6f, 0.0f);

    glEnd();

    glLoadIdentity();
    glBegin(GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.7f, 0.7f);
    glVertex2f( -0.7f, 0.7f);

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.7f, 0.7f);
    glVertex2f(-0.7f, -0.7f );

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.7f, -0.7f);
    glVertex2f(0.7f, -0.7f );

    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.7f, -0.7f);
    glVertex2f(0.7f, 0.7f );

    glEnd();


    glPushMatrix();
    glRotatef(i,0.0,0.0,0.1);
    glBegin(GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.0f, 0.5f);

    glEnd();
    glPopMatrix();

    glPushMatrix();
    glRotatef(j,0.0,0.0,0.1);
    glBegin(GL_LINES);
    glColor3f(1.0f, 1.0f, 0.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.0f, 0.5f);

    glEnd();
    glPopMatrix();

    glPopMatrix();

    glPushMatrix();
    glRotatef(k,0.0,0.0,0.1);
    glBegin(GL_LINES);
    glColor3f(1.0f, 1.0f, 1.0f);
    glVertex2f(0.0f, 0.0f);
    glVertex2f( 0.0f, 0.4f);

    glEnd();
    glPopMatrix();



    i-=0.05f;
    j-=0.1f;
    k-=0.5f;


    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(320, 320);
    glutCreateWindow("Clock Ticking");
    glutDisplayFunc(display);//
    initGL();
    glutIdleFunc(Idle);
    glutMainLoop();
    return 0;}
