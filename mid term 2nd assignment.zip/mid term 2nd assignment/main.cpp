#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include<math.h>

# define PI           3.14159265358979323846

void display() {
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
	glClear(GL_COLOR_BUFFER_BIT);         // Clear the color buffer (background)
    gluOrtho2D(-2, 2, -2, 2);

    glBegin(GL_QUADS);
    glColor3ub(150, 113, 23 );
	glVertex2f(-2, -2);                     //ground
	glVertex2f(2, -2);
	glVertex2f(2, -0.25);
	glVertex2f(-2, -0.25);
    glEnd();

    glBegin(GL_QUADS);
    glColor3ub(138, 180, 247);
	glVertex2f(-2, -0.25);                     //sky
	glVertex2f(2, -0.25);
	glVertex2f(2, 2);
	glVertex2f(-2, 2);
    glEnd();



    int i;
    GLfloat x=-1.5f; GLfloat y=1.5f; GLfloat radius =.4f;
	int triangleAmount = 20;

	GLfloat twicePi = 2.0f * PI;

	glBegin(GL_TRIANGLE_FAN);
	glColor3ub(249, 215, 28);
		glVertex2f(x, y);
		for(i = 0; i <= triangleAmount;i++) {
			glVertex2f(
                x + (radius * cos(i *  twicePi / triangleAmount)),
			    y + (radius * sin(i * twicePi / triangleAmount))
			);
		}
	glEnd();


    glBegin(GL_TRIANGLES);
    glColor3ub(234, 213, 105);
	glVertex2f(-1.95, -1.1);                    //pyramid
	glVertex2f(-1.2, -1.3);
	glVertex2f(-1.1, 0.5);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(89, 86, 85);
	glVertex2f(-1.2, -1.3);                    //pyramid
	glVertex2f(-0.35, -1.1);
	glVertex2f(-1.1, 0.5);
    glEnd();

    glScaled(1.2, 1.2, 0);
    glTranslated(2, -0.1, 0);
    glBegin(GL_TRIANGLES);
    glColor3ub(234, 213, 105);
	glVertex2f(-1.95, -1.1);                    //pyramid
	glVertex2f(-1.2, -1.3);
	glVertex2f(-1.1, 0.5);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3ub(89, 86, 85);
	glVertex2f(-1.2, -1.3);                    //pyramid
	glVertex2f(-0.35, -1.1);
	glVertex2f(-1.1, 0.5);
    glEnd();

    glFlush();  // Render now
}

/* Main function: GLUT runs as a console application starting at main()  */
int main(int argc, char** argv) {
	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutMainLoop();           // Enter the event-processing loop
	return 0;
}
